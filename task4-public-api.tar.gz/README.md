# Task 4 — Public Laravel API

Implements:

- **4A** `GET /api/v1/site/bootstrap`
- **4B** `POST /api/v1/contact-submissions`

## How to apply

Extract this archive into the root of `succeed/backend`, overwriting/adding
the same paths. Two existing files were modified (not overwritten wholesale —
diffs below), everything else is new:

- `bootstrap/app.php` — added one line to register `routes/api.php`
- `app/Providers/AppServiceProvider.php` — added two rate limiters

If you'd rather apply by hand, here are the exact diffs:

**bootstrap/app.php**
```diff
     ->withRouting(
         web: __DIR__.'/../routes/web.php',
+        api: __DIR__.'/../routes/api.php',
         commands: __DIR__.'/../routes/console.php',
         health: '/up',
     )
```

**app/Providers/AppServiceProvider.php** — `boot()` becomes:
```php
public function boot(): void
{
    RateLimiter::for('api', function (Request $request) {
        return Limit::perMinute(60)->by($request->user()?->id ?: $request->ip());
    });

    RateLimiter::for('contact', function (Request $request) {
        return Limit::perMinute(5)->by($request->ip());
    });
}
```
(plus the corresponding `use` statements for `Limit`, `Request`, `RateLimiter`)

## After applying

```bash
php artisan route:list --path=api   # sanity check the routes registered
php artisan test --filter=Api       # run the new feature tests
```

---

## 4A — `GET /api/v1/site/bootstrap`

Returns global site chrome (brand/contact info, header nav, footer) plus a
lightweight list of published pages, so a frontend can boot its shell and
routing without a second round trip.

**200 response**
```json
{
  "data": {
    "site": {
      "brand_name": "Succeed",
      "legal_name": "Succeed Education Support Services L.L.C.",
      "legal_name_short": "Succeed Education Support Services LLC",
      "flagship": { "brand": "Universities.org", "url": "https://universities.org" },
      "contact": {
        "email": "info@succeedeu.com",
        "phone": "+971 52 292 3333",
        "location": "Dubai, United Arab Emirates"
      },
      "logo_url": "http://localhost/storage/site/branding/logo.png",
      "navigation": { "items": [...], "cta": {...} },
      "footer": { ... }
    },
    "pages": [
      { "slug": "home", "name": "Home", "seo_title": "...", "seo_description": "..." }
    ]
  }
}
```

- 404 (JSON) if `site_settings` hasn't been seeded/configured yet.
- `logo_url` is `null` if no logo has been uploaded; otherwise resolved via
  the `public` disk (matches how Filament's `SiteSettings` page stores it).
- Only `is_published = true` pages are listed.

**Assumption worth flagging:** the spec just said "site bootstrap" without a
response shape, so I designed it as global chrome + page index (the common
shape for this kind of endpoint). If you only want the settings object (no
`pages` array), that's a one-line trim in `SiteController::bootstrap()`.

## 4B — `POST /api/v1/contact-submissions`

**Request body**
```json
{
  "name": "Jane Doe",
  "email": "jane@example.com",
  "phone": "+971 50 123 4567",
  "message": "Hi, I'd like to learn more..."
}
```

| Field   | Rules                                  |
|---------|-----------------------------------------|
| name    | required, string, max:255               |
| email   | required, valid email, max:255          |
| phone   | nullable, string, max:30                |
| message | required, string, min:10, max:5000      |

**201 response**
```json
{
  "message": "Thanks for reaching out. We will get back to you shortly.",
  "data": {
    "id": 42,
    "name": "Jane Doe",
    "email": "jane@example.com",
    "phone": "+971 50 123 4567",
    "status": "new",
    "created_at": "2026-07-14T12:00:00+00:00"
  }
}
```

- **422** with standard Laravel validation error shape on bad input.
- **429** if the same IP exceeds 5 requests/minute (`contact` rate limiter).
- **Honeypot spam protection:** the request also accepts an optional
  `website` field that a real user never sees or fills. If it's non-empty,
  the API responds `201` as if it succeeded (so bots get no useful signal)
  but nothing is written to the database. Wire an invisible/off-screen input
  named `website` into the frontend form to make use of this.
- New submissions land with `status = new`, matching the existing
  `ContactSubmission` model/Filament resource — they'll show up immediately
  in the admin panel's "Messages" nav badge.

## Notes / things to double check on your end

- **CORS:** no `config/cors.php` was published in this project, so Laravel's
  default config applies (`paths => ['api/*', ...]`, `allowed_origins =>
  ['*']`). Fine for a fully public API; if you need to restrict origins,
  publish and edit that config.
- **DNS email validation:** I deliberately used the plain `email` rule
  instead of `email:rfc,dns` — DNS validation can flake in some
  environments/tests and reject legitimate addresses. Easy to tighten later
  if you want it.
- No PHP runtime was available in the sandbox this was written in, so this
  wasn't executed — please run the test suite (`php artisan test --filter=Api`)
  before merging.
